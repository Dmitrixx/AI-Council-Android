package org.apache.pdfbox.text;
import java.io.IOException;
import org.apache.pdfbox.pdmodel.PDDocument;
public class PDFTextStripper { public PDFTextStripper() throws IOException{} public void setSortByPosition(boolean b){} public void setLineSeparator(String s){} public void setStartPage(int i){} public void setEndPage(int i){} public String getText(PDDocument d) throws IOException {return "test";} protected void writeString(String s) throws IOException{} }
