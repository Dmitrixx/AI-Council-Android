#!/usr/bin/env sh
set -eu
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
ROOT="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT INT TERM
find "$SCRIPT_DIR/src" -name '*.java' -print > "$TMP_DIR/sources.txt"
printf '%s\n' \
  "$ROOT/app/src/main/java/com/aicouncil/app/DocumentTextExtractor.java" \
  "$ROOT/app/src/main/java/com/aicouncil/app/EndpointPolicy.java" \
  "$ROOT/app/src/main/java/com/aicouncil/app/WebSearchPolicy.java" \
  "$ROOT/app/src/main/java/com/aicouncil/app/LocalAiPolicy.java" \
  "$ROOT/app/src/main/java/com/aicouncil/app/ProviderConfigFingerprint.java" \
  "$ROOT/app/src/main/java/com/aicouncil/app/ResultReportFormatter.java" \
  "$ROOT/app/src/main/java/com/aicouncil/app/CouncilAnalysisPolicy.java" \
  "$ROOT/app/src/main/java/com/aicouncil/app/ExpertRolePolicy.java" \
  "$ROOT/app/src/main/java/com/aicouncil/app/TruncatedAnswerPolicy.java" \
  "$ROOT/app/src/main/java/com/aicouncil/app/UiThemePolicy.java" \
  "$ROOT/app/src/main/java/com/aicouncil/app/ProviderErrorFormatter.java" \
  "$ROOT/app/src/main/java/com/aicouncil/app/SecretRedactor.java" \
  "$ROOT/app/src/main/java/com/aicouncil/app/VoicePromptPolicy.java" \
  "$ROOT/app/src/main/java/com/aicouncil/app/PromptMetricsPolicy.java" \
  "$ROOT/app/src/main/java/com/aicouncil/app/TaskRoutingPolicy.java" >> "$TMP_DIR/sources.txt"
mkdir -p "$TMP_DIR/out"
javac -encoding UTF-8 -d "$TMP_DIR/out" @"$TMP_DIR/sources.txt"
java -cp "$TMP_DIR/out" com.aicouncil.app.ExtractorSmokeTest
java -cp "$TMP_DIR/out" com.aicouncil.app.EndpointPolicySmokeTest
java -cp "$TMP_DIR/out" com.aicouncil.app.WebSearchPolicySmokeTest
java -cp "$TMP_DIR/out" com.aicouncil.app.LocalAiPolicySmokeTest

java -cp "$TMP_DIR/out" com.aicouncil.app.ProviderConfigFingerprintSmokeTest
java -cp "$TMP_DIR/out" com.aicouncil.app.ResultReportFormatterSmokeTest
java -cp "$TMP_DIR/out" com.aicouncil.app.CouncilAnalysisPolicySmokeTest

java -cp "$TMP_DIR/out" com.aicouncil.app.ExpertRolePolicySmokeTest
java -cp "$TMP_DIR/out" com.aicouncil.app.TruncatedAnswerPolicySmokeTest

java -cp "$TMP_DIR/out" com.aicouncil.app.UiThemePolicySmokeTest
java -cp "$TMP_DIR/out" com.aicouncil.app.ProviderErrorFormatterSmokeTest
java -cp "$TMP_DIR/out" com.aicouncil.app.SecretRedactorSmokeTest

java -cp "$TMP_DIR/out" com.aicouncil.app.VoicePromptPolicySmokeTest
java -cp "$TMP_DIR/out" com.aicouncil.app.PromptMetricsPolicySmokeTest
java -cp "$TMP_DIR/out" com.aicouncil.app.TaskRoutingPolicySmokeTest
