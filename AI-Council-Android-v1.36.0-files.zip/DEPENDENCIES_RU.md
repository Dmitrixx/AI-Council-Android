# Зависимости AI Council 1.36.0

- Android Gradle Plugin 7.4.2
- compileSdk 34, minSdk 23, targetSdk 34
- Java 8 для исходного кода приложения
- `com.tom-roush:pdfbox-android:2.0.27.0` — локальное извлечение текстового слоя PDF
- `com.google.mlkit:text-recognition:16.0.1` — OCR латинского письма
- `cz.adaptech.tesseract4android:tesseract4android:4.9.0` — локальный OCR кириллицы, артефакт подключается через JitPack
- Встроенных сторонних HTTP/поисковых SDK не добавлено: Brave Search, MediaWiki API и DuckDuckGo HTML/Instant Answer вызываются через `HttpURLConnection` по HTTPS.
- Подключение локального LLM-сервера использует собственный Java HTTP-клиент и OpenAI-совместимые `/v1/chat/completions` и `/v1/models` endpoints; Ollama/LM Studio не включены в APK. `LocalAiPolicy.java` и `WebSearchPolicy.java` содержат тестируемые pure-Java правила без новых внешних зависимостей.

## Языковые модели OCR

- `rus.traineddata` и `ukr.traineddata` скачиваются отдельно по выбору пользователя.
- Источник: `https://github.com/tesseract-ocr/tessdata_fast`, версия данных `4.1.0`; языковые модели сохраняются в приватной директории приложения.
- Размер модели ограничен 8 МБ; изображение/PDF не загружается для OCR.

## Поиск и локальные AI-серверы

- Brave Web Search API: `https://api.search.brave.com/res/v1/web/search`, требуется пользовательский subscription token; токен хранится зашифрованным.
- Wikipedia Search: MediaWiki Action API на локализованном домене `ru.wikipedia.org`, `uk.wikipedia.org` или `en.wikipedia.org`.
- DuckDuckGo HTML Search: `https://html.duckduckgo.com/html/`; best-effort HTML выдача, может быть ограничена службой.
- DuckDuckGo Instant Answer API: `https://api.duckduckgo.com/`; справочные ответы, не полноценный полнотекстовый индекс.
- Ollama локальный OpenAI-совместимый endpoint обычно `http://<LAN-IP>:11434/v1`; LM Studio обычно `http://<LAN-IP>:1234/v1`. Пользователь обязан заменить пример IP на реальный адрес локального хоста.
- HTTP разрешён только loopback/приватным IPv4/`.local`; HTTPS используется для облачных endpoints. Распознанные локальные HTTP- и HTTPS-endpoints могут работать без API-ключа, а сохранённый облачный ключ не передаётся в локальный адрес. Незащищённый HTTP в LAN не обеспечивает шифрование трафика.

См. `THIRD_PARTY_NOTICES_RU.md` для ссылок и сведений о внешних сервисах.


## Изменения в 1.26.0

В этом релизе не добавлено сторонних библиотек: форматирование Markdown реализовано чистым Java-классом `ResultReportFormatter`, сохранение файла выполняет системный Android Storage Access Framework, а копирование — системный буфер обмена Android.

## Изменения 1.27.0

- Новых внешних библиотек нет. `CouncilAnalysisPolicy` использует только Java 8 API и проверяется автономным `javac` smoke runner.


## Изменения 1.28.0

- Новые сторонние библиотеки не добавлялись. Настраиваемые роли и маршрутизация продолжения ответа реализованы чистыми Java-классами `ExpertRolePolicy` и `TruncatedAnswerPolicy`, которые входят в desktop smoke runner.


## Изменения 1.29.0

- Новых сторонних библиотек не добавлено.
- Иконка приложения реализована через Android adaptive-icon XML для Android 8.0+ и PNG fallback по плотностям для API 23–25.
- Фирменная тема и окно запуска используют ресурсы Android, без сторонней UI-зависимости.
- Раскрываемые секции и синхронизация нижней навигации реализованы на Android SDK.


## Изменения 1.32.0

- Сторонние зависимости не добавлялись. Три режима темы, семантическое преобразование палитры и подсчёт коэффициента контраста реализованы в `UiThemePolicy` без Android-зависимостей, поэтому класс проверяется обычным Java runner. Нативные ресурсы `AppThemeLight` и `splash_background_light` используют Android SDK.


## Дополнения версии 1.33.0

Новых сторонних библиотек нет. `ProviderErrorFormatter` использует только стандартную Java-библиотеку для классификации HTTP-ошибок и очистки диагностического текста.


## Дополнения версии 1.35.0

Новых сторонних библиотек нет. `SecretRedactor` использует только стандартные регулярные выражения Java и подключён к форматтеру HTTP-ошибок. Фильтрация секретов best-effort и применяется к отображаемым диагностическим деталям.


## Дополнения версии 1.36.0

Новых сторонних библиотек и Android-разрешений не добавлено. `PromptMetricsPolicy` и `TaskRoutingPolicy` работают на стандартных Java API; варианты голосового ввода предоставляет системная служба Android.
